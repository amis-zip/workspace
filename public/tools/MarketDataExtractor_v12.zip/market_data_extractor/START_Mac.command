#!/bin/bash
cd "$(dirname "$0")"
echo "============================================"
echo " Market Data Extractor - starting..."
echo "============================================"
if ! command -v python3 &> /dev/null; then
  echo "[ERROR] python3 not found. Install it from https://python.org"
  read -p "Press Enter to exit"
  exit 1
fi
echo "Installing required packages (first run only)..."
pip3 install flask beautifulsoup4 lxml openpyxl --quiet
echo "Opening http://localhost:5577 in your browser..."
( sleep 2 && open http://localhost:5577 ) &
python3 app.py
