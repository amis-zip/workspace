@echo off
cd /d "%~dp0"
echo ============================================
echo  Market Data Extractor - starting...
echo ============================================

rem Find Python: try "python", then "py" launcher
set PYCMD=
where python >nul 2>nul && set PYCMD=python
if not defined PYCMD (
  where py >nul 2>nul && set PYCMD=py
)
if not defined PYCMD (
  echo [ERROR] Python was not found.
  echo Install Python from https://python.org and during setup
  echo check the box "Add python.exe to PATH", then run this again.
  pause
  exit /b
)

echo Using: %PYCMD%
echo Installing required packages (first run only)...
%PYCMD% -m pip install flask beautifulsoup4 lxml openpyxl --quiet

echo Opening http://localhost:5577 in your browser...
start "" http://localhost:5577
%PYCMD% app.py
pause
