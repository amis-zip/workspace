"""네이버 브랜드스토어 / 스마트스토어 카테고리·목록 페이지 파서.

검증 기준 (실제 샘플 2종):
  - brand.naver.com/armanibeauty  -> categoryProducts.simpleProducts (80개)
  - smartstore.naver.com/ninestarfactory -> widgetContents.wholeProductWidget.A.data.simpleProducts (50개)

데이터 위치:
  네이버는 페이지에 심긴 window.__PRELOADED_STATE__(JSON)에 상품을 담습니다.
  레이아웃에 따라 상품 배열 위치가 다릅니다:
    (1) categoryProducts.simpleProducts            (카테고리형 페이지)
    (2) widgetContents.wholeProductWidget.A.data.simpleProducts  (위젯형 페이지)
  둘 다 탐색해 비어있지 않은 쪽을 사용합니다.

필드:        name / productNo / salePrice / channel.channelName
URL 도메인:  HTML에서 실제 등장한 도메인(brand|smartstore)과 슬러그를 추출해 구성.
URL 구성:    https://{domain}/{slug}/products/{productNo}

정렬 주의:
  네이버 기본 정렬은 인기순(POPULAR)이며 URL/JSON에 정렬값이 없을 수 있습니다.
  "최신 등록순"이 필요하면 페이지에서 직접 정렬을 바꾼 뒤 저장하세요.
  parse_meta() 가 읽어낸 sort 값을 앱이 경고로 표시합니다.

추천(타 셀러) 혼입:
  검증된 두 샘플 모두 목록 내 셀러는 단일(아르마니/Two Step)이었고,
  추천은 별도 필드(recommendSimpleProducts)로 분리돼 본 목록에 섞이지 않았습니다.
  추가 안전장치로, 목록에 둘 이상의 셀러(channelName)가 섞여 있으면
  parse_meta()가 그 사실과 분포를 보고하여 앱에서 셀러 필터를 쓸 수 있게 합니다.
"""
import re
import json
from collections import Counter


def _decode(html_bytes):
    for enc in ["utf-8", "euc-kr", "cp949"]:
        try:
            return html_bytes.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return html_bytes.decode("utf-8", errors="replace")


def _extract_state(html):
    i = html.find("__PRELOADED_STATE__")
    if i < 0:
        return None
    m = re.search(r"__PRELOADED_STATE__\s*=\s*", html[i:i + 200])
    if not m:
        return None
    start = i + m.end()
    depth = 0
    instr = False
    esc = False
    js = None
    for j in range(start, len(html)):
        c = html[j]
        if esc:
            esc = False
            continue
        if c == "\\":
            esc = True
            continue
        if c == '"':
            instr = not instr
            continue
        if instr:
            continue
        if c == "{":
            depth += 1
        elif c == "}":
            depth -= 1
            if depth == 0:
                js = html[start:j + 1]
                break
    if js is None:
        return None
    js = re.sub(r"\bundefined\b", "null", js)
    try:
        return json.loads(js)
    except json.JSONDecodeError:
        return None


def _product_list(state):
    """레이아웃에 따라 비어있지 않은 상품 배열을 찾아 반환. (배열, 메타dict)"""
    cp = state.get("categoryProducts") or {}
    main = cp.get("simpleProducts") or []
    if main:
        return main, {"sort": cp.get("sort"), "page": cp.get("page"),
                      "page_size": cp.get("pageSize"), "total_count": cp.get("totalCount"),
                      "source": "categoryProducts"}
    # 위젯형
    try:
        wd = state["widgetContents"]["wholeProductWidget"]["A"]["data"]
        wprods = wd.get("simpleProducts") or []
        if wprods:
            return wprods, {"sort": wd.get("resultSortType"), "page": None,
                            "page_size": None, "total_count": None,
                            "source": "wholeProductWidget"}
    except (KeyError, TypeError):
        pass
    return [], {"sort": None, "page": None, "page_size": None,
                "total_count": None, "source": None}


def _domain_slug(html):
    """HTML에 실제 등장한 도메인+슬러그 추출. brand 우선, 없으면 smartstore."""
    for dom in ("brand.naver.com", "smartstore.naver.com"):
        # 완성 URL 형태 우선
        m = re.findall(re.escape(dom) + r"/([\w-]+)/products/\d+", html)
        if m:
            return dom, Counter(m).most_common(1)[0][0]
    for dom in ("brand.naver.com", "smartstore.naver.com"):
        m = re.findall(re.escape(dom) + r"/([\w-]+)", html)
        if m:
            return dom, Counter(m).most_common(1)[0][0]
    # 상대링크
    rel = re.findall(r'href="/([\w-]+)/products/\d+"', html)
    if rel:
        return "brand.naver.com", Counter(rel).most_common(1)[0][0]
    return None, None


def _clean(s):
    return re.sub(r"[\u200b\u200c\u200d\ufeff]", "", s or "").strip()


def parse(html_bytes, seller_only=None):
    """
    seller_only: 지정 시 channelName이 그 값과 같은 상품만 (타 셀러/추천 제외).
    """
    html = _decode(html_bytes)
    state = _extract_state(html)
    if not state:
        return []
    prods, _ = _product_list(state)
    domain, slug = _domain_slug(html)
    rows = []
    for p in prods:
        no = p.get("productNo")
        if not no:
            continue
        ch = (p.get("channel") or {}).get("channelName", "")
        if seller_only and ch != seller_only:
            continue
        url = f"https://{domain}/{slug}/products/{no}" if (domain and slug) else ""
        img = (p.get("representativeImageUrl") or "").strip()
        rows.append({
            "title": _clean(p.get("name") or p.get("dispName")),
            "url": url,
            "price": str(p.get("salePrice", "")),
            "seller": ch,
            "image": img,
        })
    return rows


def store_name(html_bytes):
    state = _extract_state(_decode(html_bytes))
    if not state:
        return ""
    prods, _ = _product_list(state)
    if prods and isinstance(prods[0].get("channel"), dict):
        return prods[0]["channel"].get("channelName", "") or ""
    return ""


def parse_meta(html_bytes):
    html = _decode(html_bytes)
    state = _extract_state(html)
    if not state:
        return {}
    prods, meta = _product_list(state)
    sort = meta.get("sort")
    is_recent = isinstance(sort, str) and any(
        k in sort.upper() for k in ("RECENT", "LATEST", "REG", "NEW")
    )
    domain, slug = _domain_slug(html)
    sellers = Counter(((p.get("channel") or {}).get("channelName")) for p in prods)
    return {
        "sort": sort,
        "is_recent_sort": is_recent,
        "page": meta.get("page"),
        "page_size": meta.get("page_size"),
        "total_count": meta.get("total_count"),
        "slug_found": bool(slug),
        "domain": domain,
        "source": meta.get("source"),
        "seller_count": len(sellers),
        "sellers": dict(sellers),
    }


def detect(html_bytes):
    """이 HTML이 네이버 스토어 페이지인지 판별."""
    html = _decode(html_bytes)
    if "__PRELOADED_STATE__" not in html:
        return False
    return ("brand.naver.com" in html) or ("smartstore.naver.com" in html) or ("categoryProducts" in html)
