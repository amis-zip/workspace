"""
마켓별 HTML 파서 레지스트리.

새 마켓을 추가하려면:
  1. parsers/ 안에 새 파일을 만들고 parse(html_bytes) -> list[dict] 함수를 구현
     (각 dict는 {'title': str, 'url': str, 'price': str} 형태)
  2. (선택) store_name(html_bytes) -> str, parse_meta(html_bytes) -> dict 구현
  3. 아래 PARSERS 에 등록
  4. 끝. UI 드롭다운에 자동으로 나타납니다.

주의: 실제 HTML 샘플 없이 파서를 미리 만들지 마세요.
구조(CSS 클래스 / JSON 경로)는 마켓마다 완전히 다르며, 추측으로 만든
파서는 동작하지 않는 죽은 코드가 됩니다.
"""
from . import elevenst, naver, coupang

PARSERS = {
    "11st":    {"label": "11번가",        "fn": elevenst.parse, "mod": elevenst, "ready": True},
    "naver":   {"label": "네이버 스토어",   "fn": naver.parse,    "mod": naver,    "ready": True},
    "coupang": {"label": "쿠팡",          "fn": coupang.parse,  "mod": coupang,  "ready": True},
}

PLANNED = {}


def get_parser(market_key):
    entry = PARSERS.get(market_key)
    return entry["fn"] if entry else None


def get_module(market_key):
    entry = PARSERS.get(market_key)
    return entry.get("mod") if entry else None


def available_markets():
    out = [(k, v["label"], True) for k, v in PARSERS.items()]
    for k, label in PLANNED.items():
        if k not in PARSERS:
            out.append((k, label, False))
    return out


def detect_market(html_bytes):
    """HTML이 어느 마켓 것인지 자동 감지. (key 또는 None)"""
    for key, entry in PARSERS.items():
        mod = entry.get("mod")
        if mod and hasattr(mod, "detect"):
            try:
                if mod.detect(html_bytes):
                    return key
            except Exception:
                continue
    return None
