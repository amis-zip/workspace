"""쿠팡 브랜드샵 페이지 파서.

검증 기준 (실제 샘플: coupang.com/np/products/brand-shop?brandName=롯데웰푸드, 60개 노출):
  - 데이터 위치: DOM (서버 렌더). JSON 상태 객체는 없음.
  - 컨테이너:   li[class^="ProductUnit_productUnit"]  (CSS Modules 해시 클래스)
  - 상품명:     [class^="ProductUnit_productName"]
  - 링크:       a[href^="/vp/products/{id}"]
  - 가격:       [class^="Price_priceValue"]
  - URL 구성:   https://www.coupang.com/vp/products/{id}  (쿼리스트링 제거)

한계 (반드시 인지) ─────────────────────────────────────────
  1. CSS Modules 해시 클래스(ProductUnit_productUnit__Qd6sv 등)는 쿠팡이 프론트엔드를
     재배포하면 해시가 바뀝니다. 그래서 해시를 뺀 '접두어'로 매칭하지만,
     쿠팡이 클래스명 자체를 바꾸면 파서가 0개를 반환할 수 있습니다.
     -> 그럴 땐 샘플 HTML을 다시 받아 접두어를 갱신해야 합니다.
  2. 같은 상품(productId)이 추천/캐러셀 위젯으로 여러 번 노출됩니다.
     실제 샘플 60개 중 productId 기준 고유는 46개였습니다.
     -> productId 기준 중복 제거(첫 등장 순서 유지)를 기본 적용합니다.
  3. 본 목록과 추천 위젯이 같은 컨테이너에 섞여 있어 DOM만으로 구분 불가.
     중복 제거 후에도 추천 상품이 일부 섞일 수 있으니 미리보기 검수가 필요합니다.
  4. 정렬: 페이지에서 직접 정렬을 설정한 뒤 저장해야 합니다(URL/DOM에 신뢰할 정렬값 없음).
─────────────────────────────────────────────────────────
"""
import re
from bs4 import BeautifulSoup


def _decode(html_bytes):
    for enc in ["utf-8", "euc-kr", "cp949"]:
        try:
            return html_bytes.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return html_bytes.decode("utf-8", errors="replace")


def parse(html_bytes):
    soup = BeautifulSoup(_decode(html_bytes), "lxml")
    items = soup.find_all("li", class_=re.compile(r"ProductUnit_productUnit"))
    rows = []
    seen = set()
    for it in items:
        a = it.find("a", href=re.compile(r"/vp/products/\d+"))
        href = a.get("href") if a else ""
        pid_m = re.search(r"/vp/products/(\d+)", href)
        pid = pid_m.group(1) if pid_m else ""
        if not pid or pid in seen:   # productId 기준 중복 제거
            continue
        seen.add(pid)
        url = "https://www.coupang.com/vp/products/" + pid
        name_el = it.find(class_=re.compile(r"ProductUnit_productName"))
        name = name_el.get_text(strip=True) if name_el else ""
        price_el = it.find(class_=re.compile(r"Price_priceValue"))
        price = price_el.get_text(strip=True) if price_el else ""
        # 썸네일: 상품 이미지 컨테이너 안의 img만 (로고/뱃지 배제)
        img_wrap = it.find(class_=re.compile(r"ProductUnit_productImage"))
        img_el = img_wrap.find("img") if img_wrap else None
        img = ""
        if img_el:
            img = (img_el.get("src") or img_el.get("data-src") or "").strip()
            if img.startswith("//"):
                img = "https:" + img
            if not (img.startswith("http://") or img.startswith("https://")):
                img = ""
        rows.append({"title": name, "url": url, "price": price, "image": img})
    return rows


def store_name(html_bytes):
    html = _decode(html_bytes)
    m = re.search(r"brandName=([^\"&]+)", html)
    if m:
        from urllib.parse import unquote
        return unquote(m.group(1))
    return ""


def parse_meta(html_bytes):
    """원시 노출 수 vs 중복 제거 후 수 (검수용)."""
    soup = BeautifulSoup(_decode(html_bytes), "lxml")
    raw = soup.find_all("li", class_=re.compile(r"ProductUnit_productUnit"))
    rows = parse(html_bytes)
    return {
        "raw_count": len(raw),
        "deduped_count": len(rows),
        "removed_dupes": len(raw) - len(rows),
    }


def detect(html_bytes):
    """이 HTML이 쿠팡 페이지인지 판별."""
    html = _decode(html_bytes)
    return ("ProductUnit_productUnit" in html) or ("coupang.com" in html and "/vp/products/" in html)
