"""11번가 스토어 검색결과 HTML 파서.

검증 기준 (실제 샘플 1046274 / 블루피넛 스토어, 315개 상품):
  - 컨테이너:  .store_product_item
  - 상품명:    .store_product_name
  - 링크:      a.store_product_link  (href -> products/{id})
  - 가격:      .store_product_new_price
  - 인코딩:    EUC-KR (11번가 기본). UTF-8 폴백 처리.
  - 정렬:      11번가가 내려준 DOM 표시 순서를 그대로 유지.
              products 번호로 재정렬하지 않음 (실제 등록순 왜곡 방지).
"""
import re
from bs4 import BeautifulSoup


def _decode(html_bytes):
    """charset 힌트 우선, 실패 시 euc-kr -> utf-8 폴백."""
    head = html_bytes[:3000]
    m = re.search(rb'charset=["\']?([\w-]+)', head, re.I)
    encodings = []
    if m:
        encodings.append(m.group(1).decode("ascii", "ignore").lower())
    for enc in ["euc-kr", "cp949", "utf-8"]:
        if enc not in encodings:
            encodings.append(enc)
    for enc in encodings:
        try:
            return html_bytes.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return html_bytes.decode("euc-kr", errors="replace")


def parse(html_bytes):
    """HTML 바이트 -> [{'title','url','price'}] (DOM 순서 유지)."""
    soup = BeautifulSoup(_decode(html_bytes), "lxml")
    items = soup.select(".store_product_item")
    rows = []
    for it in items:
        a = it.select_one("a.store_product_link") or it.find("a", href=True)
        url = (a.get("href") if a else "") or ""
        url = url.split("?")[0].strip()
        name_el = it.select_one(".store_product_name")
        title = name_el.get_text(strip=True) if name_el else ""
        price_el = it.select_one(".store_product_new_price")
        price = price_el.get_text(strip=True) if price_el else ""
        if not url and not title:
            continue
        rows.append({"title": title, "url": url, "price": price,
                     "image": _img(it)})
    return rows


def _img(it):
    """상품 썸네일 추출. 절대 URL만 반환(로컬 저장 상대경로는 제외)."""
    img = it.select_one(".store_product_thumb") or it.find("img")
    if not img:
        return ""
    src = (img.get("src") or img.get("data-src")
           or img.get("data-original") or "").strip()
    if src.startswith("//"):
        src = "https:" + src
    # "웹페이지 완전 저장" 시 ./..._files/ 로 바뀐 로컬 경로는 버림
    if src.startswith("http://") or src.startswith("https://"):
        return src
    return ""


def store_name(html_bytes):
    """스토어명 추출 (.store_name). 없으면 빈 문자열."""
    soup = BeautifulSoup(_decode(html_bytes), "lxml")
    el = soup.select_one(".store_name")
    return el.get_text(strip=True) if el else ""


def detect(html_bytes):
    """이 HTML이 11번가 페이지인지 판별."""
    html = _decode(html_bytes)
    return ("store_product_item" in html) or ("11st.co.kr" in html and "store_product" in html)
