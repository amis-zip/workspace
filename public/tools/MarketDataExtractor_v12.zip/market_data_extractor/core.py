"""필터링 + Excel 생성 핵심 로직 (웹 계층과 분리)."""
import io
import re
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill

HEADERS = ["고지일자", "platform", "mall_name", "TITLE", "URL"]
PINK = "FFF0F3"   # 스트로베리 밀크 톤 (헤더 배경)


def _split_keywords(s):
    """쉼표/줄바꿈으로 구분된 키워드 문자열 -> 공백제거 리스트."""
    if not s:
        return []
    parts = re.split(r"[,\n]", s)
    return [p.strip() for p in parts if p.strip()]


def apply_filter(rows, include_kw, exclude_kw, match_mode="any"):
    """
    rows: [{'title','url','price'}]
    include_kw / exclude_kw: 키워드 리스트
    match_mode: 'any' (포함 키워드 중 하나라도) / 'all' (전부)

    반환: (matched, dropped)
      - matched: 포함 조건 충족 & 제외 조건 미해당 -> 대상
      - dropped: 그 외 -> 제외됨 (사유 포함)
    원래 순서(DOM 순서) 유지.
    """
    matched, dropped = [], []
    for r in rows:
        title = r.get("title", "")
        # 제외 키워드 우선 체크
        hit_excl = next((k for k in exclude_kw if k and k in title), None)
        if hit_excl:
            dropped.append({**r, "reason": f"제외 키워드 '{hit_excl}'"})
            continue
        # 포함 키워드 체크
        if include_kw:
            hits = [k for k in include_kw if k and k in title]
            ok = (len(hits) == len([k for k in include_kw if k])) if match_mode == "all" else bool(hits)
            if ok:
                matched.append({**r, "reason": f"포함: {', '.join(hits)}"})
            else:
                dropped.append({**r, "reason": "포함 키워드 미해당"})
        else:
            # 포함 키워드 없으면 제외 안 걸린 전부 통과
            matched.append({**r, "reason": "전체(포함 키워드 없음)"})
    return matched, dropped


def build_workbook(matched, dropped, platform, mall_name, notify_date,
                   limit=None, include_dropped_sheet=True):
    """
    matched/dropped: apply_filter 결과
    limit: 대상 시트 상위 N개만 (None=전체)
    반환: (BytesIO, 통계 dict)
    """
    target = matched[:limit] if limit else matched
    rest = matched[limit:] if limit else []

    try:
        d = datetime.strptime(notify_date, "%Y-%m-%d")
    except (ValueError, TypeError):
        d = datetime.now()

    wb = Workbook()

    def fill(ws, data):
        ws.append(HEADERS)
        for c in ws[1]:
            c.font = Font(bold=True, name="Arial")
            c.fill = PatternFill("solid", start_color=PINK)
        for row in data:
            ws.append([d, platform, mall_name, row["title"], row["url"]])
        for ridx in range(2, len(data) + 2):
            ws.cell(ridx, 1).number_format = "yyyy-mm-dd"
            for cidx in range(1, 6):
                ws.cell(ridx, cidx).font = Font(name="Arial")
        for col, w in zip("ABCDE", [14, 10, 16, 55, 50]):
            ws.column_dimensions[col].width = w

    ws_main = wb.active
    ws_main.title = "ESSE"
    fill(ws_main, target)

    if rest:
        fill(wb.create_sheet("나머지(상위N 제외)"), rest)

    if include_dropped_sheet and dropped:
        ws_d = wb.create_sheet("제외됨_참고")
        ws_d.append(HEADERS + ["제외사유"])
        for c in ws_d[1]:
            c.font = Font(bold=True, name="Arial")
            c.fill = PatternFill("solid", start_color=PINK)
        for row in dropped:
            ws_d.append([d, platform, mall_name, row["title"], row["url"], row.get("reason", "")])
        for ridx in range(2, len(dropped) + 2):
            ws_d.cell(ridx, 1).number_format = "yyyy-mm-dd"
        for col, w in zip("ABCDEF", [14, 10, 16, 55, 50, 22]):
            ws_d.column_dimensions[col].width = w

    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    stats = {
        "total": len(matched) + len(dropped),
        "matched": len(matched),
        "dropped": len(dropped),
        "target": len(target),
        "rest": len(rest),
    }
    return bio, stats
