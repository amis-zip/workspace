"""
AMCR 수동입력 도구 — 로컬 웹 앱.

흐름: HTML 업로드 -> 마켓 파서로 추출 -> 포함/제외 키워드 필터
     -> 결과 미리보기(브라우저) -> 확정 후 Excel 다운로드.

자동화되지 않는 것 (의도적):
  - HTML 확보: 11번가가 봇을 막으므로 사람이 직접 페이지를 저장해야 함.
  - 필터 키워드 결정: 브랜드/스토어마다 다르므로 사람이 정해야 함.
이 도구는 '파싱 -> 필터 -> 검증 -> Excel' 단계만 표준화합니다.
"""
import base64
from flask import Flask, render_template, request, jsonify, send_file
from datetime import date

from parsers import available_markets, get_parser, get_module, detect_market
from core import apply_filter, build_workbook, _split_keywords

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB


def _store_name(market, html_bytes):
    mod = get_module(market)
    if mod and hasattr(mod, "store_name"):
        try:
            return mod.store_name(html_bytes)
        except Exception:
            return ""
    return ""


def _warnings(market, html_bytes):
    """마켓별 검수 경고 (정렬, 중복 등). 미리보기에 노출."""
    mod = get_module(market)
    if not (mod and hasattr(mod, "parse_meta")):
        return []
    try:
        meta = mod.parse_meta(html_bytes)
    except Exception:
        return []
    out = []
    if market == "naver":
        if meta.get("sort") and not meta.get("is_recent_sort"):
            out.append(f"⚠️ 네이버 정렬이 '{meta['sort']}'(최신순 아님)입니다. "
                       f"'최신 등록순'이 필요하면 페이지에서 정렬을 바꿔 다시 저장하세요.")
        if not meta.get("slug_found"):
            out.append("⚠️ 스토어 슬러그를 찾지 못해 일부 상품 URL이 비어 있을 수 있습니다.")
        tc, ps = meta.get("total_count"), meta.get("page_size")
        if tc and ps and tc > ps:
            out.append(f"ℹ️ 이 페이지는 {ps}개입니다. 카테고리 전체는 {tc}개 — "
                       f"다음 페이지도 따로 저장해 합쳐야 전체가 됩니다.")
        sc = meta.get("seller_count", 0)
        if sc > 1:
            dist = ", ".join(f"{k}({v})" for k, v in (meta.get("sellers") or {}).items())
            out.append(f"⚠️ 이 목록에 셀러가 {sc}곳 섞여 있습니다: {dist}. "
                       f"특정 셀러만 남기려면 아래 '셀러 필터'를 사용하세요.")
    if market == "coupang":
        rem = meta.get("removed_dupes", 0)
        if rem:
            out.append(f"ℹ️ 쿠팡 중복 {rem}개를 productId 기준으로 제거했습니다 "
                       f"(노출 {meta.get('raw_count')} → {meta.get('deduped_count')}). "
                       f"추천 위젯 상품이 일부 섞일 수 있으니 목록을 확인하세요.")
    return out


@app.route("/")
def index():
    return render_template("index.html",
                           markets=available_markets(),
                           today=date.today().isoformat())


def _parse_files(market, files, seller_only=None):
    """여러 HTML을 순서대로 파싱 → URL 기준 중복 제거하며 병합.
    반환: (merged_rows, per_file_meta_list, first_file_bytes)"""
    parser = get_parser(market)
    mod = get_module(market)
    merged = []
    seen = set()
    per_file = []
    first_bytes = None
    for idx, f in enumerate(files):
        hb = f.read()
        if first_bytes is None:
            first_bytes = hb
        try:
            # naver parser supports seller_only kwarg
            if market == "naver" and seller_only:
                rows = parser(hb, seller_only=seller_only)
            else:
                rows = parser(hb)
        except TypeError:
            rows = parser(hb)
        added = 0
        for r in rows:
            key = r.get("url") or (r.get("title"), r.get("price"))
            if key in seen:
                continue
            seen.add(key)
            merged.append(r)
            added += 1
        meta = mod.parse_meta(hb) if (mod and hasattr(mod, "parse_meta")) else {}
        per_file.append({"name": getattr(f, "filename", f"file{idx+1}"),
                         "parsed": len(rows), "new": added, "meta": meta})
    return merged, per_file, first_bytes


@app.route("/preview", methods=["POST"])
def preview():
    market = request.form.get("market", "")
    parser = get_parser(market)
    if parser is None:
        label = dict((k, l) for k, l, _ in available_markets()).get(market, market)
        return jsonify({"error": f"'{label}' 파서는 아직 없습니다. 해당 마켓 HTML 샘플을 받아 파서를 추가해야 합니다."}), 400

    files = request.files.getlist("html_file")
    files = [f for f in files if f and f.filename]
    if not files:
        return jsonify({"error": "HTML 파일이 없습니다."}), 400

    seller_only = request.form.get("seller_only", "").strip() or None

    try:
        rows, per_file, first_bytes = _parse_files(market, files, seller_only)
    except Exception as e:
        return jsonify({"error": f"파싱 실패: {e}"}), 500

    if not rows:
        # 0개일 때: 업로드한 HTML이 사실 다른 마켓인지 자동 감지
        detected = None
        try:
            detected = detect_market(first_bytes)
        except Exception:
            detected = None
        labels = dict((k, l) for k, l, _ in available_markets())
        if detected and detected != market:
            return jsonify({"error":
                f"이 HTML은 '{labels.get(detected, detected)}' 페이지로 보입니다. "
                f"지금 '{labels.get(market, market)}'를 선택하셨습니다 — "
                f"위 '1. 마켓 선택'을 '{labels.get(detected, detected)}'로 바꾼 뒤 다시 미리보기 하세요.",
                "suggest_market": detected}), 400
        return jsonify({"error":
            "상품을 찾지 못했습니다. ① 마켓 선택이 파일과 맞는지, "
            "② 페이지를 끝까지 스크롤한 뒤 저장했는지 확인하세요."}), 400

    inc = _split_keywords(request.form.get("include", ""))
    exc = _split_keywords(request.form.get("exclude", ""))
    mode = request.form.get("match_mode", "any")
    matched, dropped = apply_filter(rows, inc, exc, mode)

    store = _store_name(market, first_bytes)
    warns = _warnings(market, first_bytes)

    # 다중 파일 병합 안내
    if len(files) > 1:
        detail = " · ".join(f"{pf['name']}: +{pf['new']}" for pf in per_file)
        warns.insert(0, f"ℹ️ {len(files)}개 파일 병합 → 중복 제거 후 {len(rows)}개 ({detail})")

    # 셀러 목록(네이버) — UI 셀러 필터 채우기용
    sellers = {}
    if market == "naver":
        m0 = per_file[0]["meta"] if per_file else {}
        sellers = m0.get("sellers", {}) or {}

    # 미리보기 행 수 (사용자 지정, 기본 50, 안전 상한 1000)
    try:
        pv = int(request.form.get("preview_limit", "50"))
    except ValueError:
        pv = 50
    pv = max(1, min(pv, 1000))

    def slim(lst, n):
        return [{"title": r["title"], "url": r["url"],
                 "price": r.get("price", ""), "reason": r.get("reason", ""),
                 "seller": r.get("seller", ""), "image": r.get("image", "")}
                for r in lst[:n]]

    return jsonify({
        "total": len(rows),
        "matched": len(matched),
        "dropped": len(dropped),
        "store_name": store,
        "warnings": warns,
        "sellers": sellers,
        "preview_limit": pv,
        "matched_preview": slim(matched, pv),
        "dropped_preview": slim(dropped, pv),
        "matched_truncated": len(matched) > pv,
        "dropped_truncated": len(dropped) > pv,
    })


@app.route("/download", methods=["POST"])
def download():
    market = request.form.get("market", "")
    parser = get_parser(market)
    if parser is None:
        return jsonify({"error": "유효하지 않은 마켓"}), 400

    files = request.files.getlist("html_file")
    files = [f for f in files if f and f.filename]
    if not files:
        return jsonify({"error": "HTML 파일이 없습니다."}), 400

    seller_only = request.form.get("seller_only", "").strip() or None
    rows, _per, _fb = _parse_files(market, files, seller_only)

    inc = _split_keywords(request.form.get("include", ""))
    exc = _split_keywords(request.form.get("exclude", ""))
    mode = request.form.get("match_mode", "any")
    matched, dropped = apply_filter(rows, inc, exc, mode)

    platform = request.form.get("platform", "").strip()
    mall_name = request.form.get("mall_name", "").strip()
    notify = request.form.get("notify_date", date.today().isoformat())
    limit_raw = request.form.get("limit", "").strip()
    limit = int(limit_raw) if limit_raw.isdigit() and int(limit_raw) > 0 else None
    inc_dropped = request.form.get("include_dropped", "1") == "1"

    bio, stats = build_workbook(matched, dropped, platform, mall_name,
                                notify, limit=limit,
                                include_dropped_sheet=inc_dropped)

    brand = mall_name or "브랜드"
    fname = f"[AMCR]_{brand}_{platform or market}_{notify}_v1.xlsx"
    return send_file(bio, as_attachment=True, download_name=fname,
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


if __name__ == "__main__":
    print("=" * 50)
    print(" Market Data Extractor v12  ->  http://localhost:5577")
    print(" (Press CTRL+C to stop)")
    print("=" * 50)
    app.run(host="127.0.0.1", port=5577, debug=False)
